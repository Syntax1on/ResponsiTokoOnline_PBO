# Cat Mood Detector — Lightweight Offline Prototype

This lightweight prototype is designed to run **without TensorFlow**.
It uses OpenCV Haar cascades (if available) and simple image heuristics
to guess whether an uploaded image contains a cat and to estimate a
very naive "mood" based on eye detection and mouth openness heuristics.

**Limitations**
- It's a heuristic PoC, not a trained model. Accuracy will be limited.
- Some Haar cascades (like `haarcascade_frontalcatface.xml`) may not be
  included in every OpenCV build. The app falls back to eye-detection heuristics.

## Requirements
- Python 3.8+
- pip install -r requirements.txt

## Run
1. Extract the zip.
2. (Optional) Create & activate a virtualenv.
3. Install deps: `pip install -r requirements.txt`
4. Run: `python app.py`
5. Open http://127.0.0.1:5000 and upload an image.

