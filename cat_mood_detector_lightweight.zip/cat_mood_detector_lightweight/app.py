import os
from flask import Flask, request, render_template, jsonify
from werkzeug.utils import secure_filename
from PIL import Image
import numpy as np
import cv2

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
ALLOWED_EXT = {'png','jpg','jpeg','gif'}

def allowed_file(fn):
    return '.' in fn and fn.rsplit('.',1)[1].lower() in ALLOWED_EXT

def try_load_cascade(name):
    path = cv2.data.haarcascades + name
    if os.path.exists(path):
        return cv2.CascadeClassifier(path)
    return None

# try cat face cascade (may not exist in all builds), else fallback to human face/eyes
cat_cascade = try_load_cascade('haarcascade_frontalcatface.xml') or try_load_cascade('haarcascade_frontalcatface_extended.xml')
eye_cascade = try_load_cascade('haarcascade_eye.xml')
face_cascade = try_load_cascade('haarcascade_frontalface_default.xml')

def detect_cat_by_cascade(img_gray, img_color):
    """Return True if a cat face is detected by cascade; also return bounding boxes."""
    if cat_cascade is not None:
        cats = cat_cascade.detectMultiScale(img_gray, scaleFactor=1.1, minNeighbors=3, minSize=(75,75))
        if len(cats) > 0:
            return True, cats
    # fallback: if human face detected but small and with pointy ears maybe not cat -> ignore
    # use eye detections as weak signal
    if eye_cascade is not None:
        eyes = eye_cascade.detectMultiScale(img_gray, scaleFactor=1.1, minNeighbors=5, minSize=(20,20))
        # lots of small eye-like features can indicate an animal face; heuristic threshold:
        if len(eyes) >= 2:
            return True, eyes
    return False, []

def estimate_mood(img_color_bgr):
    gray = cv2.cvtColor(img_color_bgr, cv2.COLOR_BGR2GRAY)
    # Attempt to detect eyes; if none -> maybe sleeping/relaxed
    eyes = []
    if eye_cascade is not None:
        eyes = eye_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(20,20))
    # Heuristic:
    # - 0 eyes detected -> Relaxed / Sleeping
    # - 1 eye -> Neutral / Calm
    # - 2+ eyes -> Alert / Curious (and compute avg eye width to refine)
    if len(eyes) == 0:
        return 'Relaxed / Sleeping', {'eyes': 0}
    elif len(eyes) == 1:
        return 'Neutral / Calm', {'eyes': 1}
    else:
        widths = [w for (x,y,w,h) in eyes]
        avg_w = sum(widths)/len(widths)
        if avg_w > 35:
            return 'Alert / Curious', {'eyes': len(eyes), 'avg_eye_width': avg_w}
        else:
            return 'Neutral / Calm', {'eyes': len(eyes), 'avg_eye_width': avg_w}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error':'no file uploaded'}), 400
    file = request.files['file']
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'error':'invalid file'}), 400
    fname = secure_filename(file.filename)
    path = os.path.join(app.config['UPLOAD_FOLDER'], fname)
    file.save(path)
    pil = Image.open(path).convert('RGB')
    img_np = np.array(pil)
    img_bgr = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)

    is_cat, boxes = detect_cat_by_cascade(gray, img_bgr)
    mood = 'Unknown'
    debug = {'cat_cascade_loaded': bool(cat_cascade), 'eye_cascade_loaded': bool(eye_cascade), 'face_cascade_loaded': bool(face_cascade)}
    if is_cat:
        mood, info = estimate_mood(img_bgr)
        debug.update(info)
    else:
        # additional simple heuristic: check for furry texture by high-frequency edges
        edges = cv2.Canny(gray, 100, 200)
        edge_density = float(np.sum(edges>0)) / edges.size
        debug['edge_density'] = edge_density
        if edge_density > 0.02:
            # could be fur, weak signal for animal
            mood, info = estimate_mood(img_bgr)
            debug.update(info)
            debug['heuristic'] = 'edge_density'
            is_cat = True  # weak positive
        else:
            mood = 'No cat detected'
    return jsonify({'mood': mood, 'is_cat': bool(is_cat), 'debug': debug})

if __name__ == '__main__':
    app.run(debug=True)
